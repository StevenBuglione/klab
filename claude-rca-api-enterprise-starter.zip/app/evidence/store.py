from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from app.evidence.models import EvidenceItem

CREATE_SQL = '''
CREATE TABLE IF NOT EXISTS evidence (
  run_id TEXT NOT NULL,
  evidence_id TEXT NOT NULL,
  source TEXT NOT NULL,
  locator TEXT NOT NULL,
  content TEXT NOT NULL,
  content_sha256 TEXT NOT NULL,
  metadata_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (run_id, evidence_id)
);
CREATE INDEX IF NOT EXISTS idx_evidence_run_id ON evidence(run_id);
'''

class EvidenceStore:
    def add(self, *, run_id: str, source: str, locator: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> EvidenceItem:
        raise NotImplementedError

    def get(self, *, run_id: str, evidence_id: str) -> EvidenceItem:
        raise NotImplementedError

    def list(self, *, run_id: str) -> List[EvidenceItem]:
        raise NotImplementedError

    def search(self, *, run_id: str, query: str, limit: int = 20) -> List[EvidenceItem]:
        raise NotImplementedError

class SQLiteEvidenceStore(EvidenceStore):
    def __init__(self, db_path: str):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.executescript(CREATE_SQL)

    def add(self, *, run_id: str, source: str, locator: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> EvidenceItem:
        meta = metadata or {}
        content_sha256 = hashlib.sha256(content.encode("utf-8")).hexdigest()
        created_at = datetime.now(timezone.utc)

        with self._lock:
            with self._conn() as conn:
                cur = conn.execute("SELECT COUNT(*) AS n FROM evidence WHERE run_id = ?", (run_id,))
                n = int(cur.fetchone()["n"])
                evidence_id = f"E{n+1}"

                conn.execute(
                    "INSERT INTO evidence(run_id,evidence_id,source,locator,content,content_sha256,metadata_json,created_at) VALUES (?,?,?,?,?,?,?,?)",
                    (
                        run_id,
                        evidence_id,
                        source,
                        locator,
                        content,
                        content_sha256,
                        json.dumps(meta, separators=(",", ":")),
                        created_at.isoformat(),
                    ),
                )

        return EvidenceItem(
            run_id=run_id,
            evidence_id=evidence_id,
            source=source,
            locator=locator,
            content=content,
            content_sha256=content_sha256,
            metadata=meta,
            created_at=created_at,
        )

    def get(self, *, run_id: str, evidence_id: str) -> EvidenceItem:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM evidence WHERE run_id = ? AND evidence_id = ?",
                (run_id, evidence_id),
            ).fetchone()
        if not row:
            raise KeyError(f"Evidence not found: {run_id=} {evidence_id=}")
        return EvidenceItem(
            run_id=row["run_id"],
            evidence_id=row["evidence_id"],
            source=row["source"],
            locator=row["locator"],
            content=row["content"],
            content_sha256=row["content_sha256"],
            metadata=json.loads(row["metadata_json"]) if row["metadata_json"] else {},
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    def list(self, *, run_id: str) -> List[EvidenceItem]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM evidence WHERE run_id = ? ORDER BY CAST(SUBSTR(evidence_id,2) AS INT) ASC",
                (run_id,),
            ).fetchall()
        items: List[EvidenceItem] = []
        for row in rows:
            items.append(
                EvidenceItem(
                    run_id=row["run_id"],
                    evidence_id=row["evidence_id"],
                    source=row["source"],
                    locator=row["locator"],
                    content=row["content"],
                    content_sha256=row["content_sha256"],
                    metadata=json.loads(row["metadata_json"]) if row["metadata_json"] else {},
                    created_at=datetime.fromisoformat(row["created_at"]),
                )
            )
        return items

    def search(self, *, run_id: str, query: str, limit: int = 20) -> List[EvidenceItem]:
        q = f"%{query}%"
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM evidence WHERE run_id = ? AND (content LIKE ? OR locator LIKE ?) LIMIT ?",
                (run_id, q, q, limit),
            ).fetchall()
        return [
            EvidenceItem(
                run_id=row["run_id"],
                evidence_id=row["evidence_id"],
                source=row["source"],
                locator=row["locator"],
                content=row["content"],
                content_sha256=row["content_sha256"],
                metadata=json.loads(row["metadata_json"]) if row["metadata_json"] else {},
                created_at=datetime.fromisoformat(row["created_at"]),
            )
            for row in rows
        ]
