from __future__ import annotations

from typing import Any, Dict
from claude_agent_sdk import HookContext
from app.core.logging import get_logger

log = get_logger("agent.hooks")

async def log_pre_tool_use(input_data: Dict[str, Any], tool_use_id: str | None, context: HookContext):
    log.info(
        "tool.pre",
        tool_name=input_data.get("tool_name"),
        tool_use_id=tool_use_id,
        tool_input=input_data.get("tool_input"),
    )
    return {}

async def log_post_tool_use(input_data: Dict[str, Any], tool_use_id: str | None, context: HookContext):
    log.info(
        "tool.post",
        tool_name=input_data.get("tool_name"),
        tool_use_id=tool_use_id,
        tool_output=input_data.get("tool_output"),
        is_error=input_data.get("is_error"),
    )
    return {}
