# Claude Code RCA API (Starter) — FastAPI + Claude Agent SDK + Bedrock + Skills + MCP

This starter boots a FastAPI service that runs a Claude Code agent (via the **Claude Agent SDK**) inside Docker,
configured to use **Amazon Bedrock** as the model provider. The agent loads **Claude Code Skills** from `.claude/skills/`
and MCP servers from `.mcp.json`.

## Prereqs
- Docker + Docker Compose
- AWS credentials with access to Bedrock + Anthropic models
- Access granted to the Bedrock inference profile / model you plan to use

## Quick start

1) Copy env file and fill in values:

```bash
cp .env.example .env
```

2) Start the API:

```bash
docker compose up --build
```

3) Smoke test Bedrock connectivity (runs inside container):

```bash
docker compose exec rca-api bash -lc 'claude -p "Say hello from Bedrock" --output-format json | jq -r .result'
```

4) Call the RCA endpoint:

```bash
curl -s http://localhost:8000/v1/rca \
  -H 'content-type: application/json' \
  -d '{
    "pipeline_ref": "JENKINS_JOB=my-job BUILD=123",
    "question": "Why did the pipeline fail? Provide a root cause and recommended fixes."
  }' | jq
```

## Where to put your MCP tools

Edit `.mcp.json` and add servers for:
- Jenkins MCP
- Bitbucket MCP
- Confluence MCP
- SourceBot MCP

The example includes a **filesystem MCP server** so you can verify MCP wiring quickly.

## Skills

A sample Skill is provided at:
`.claude/skills/jenkins-rca/SKILL.md`

Claude Code will automatically apply the Skill when the prompt matches its description.

## Security note

This starter uses `permission_mode=bypassPermissions` to avoid interactive prompts in containers.
In production, tighten this by:
- restricting tools (`disallowed_tools`)
- using `can_use_tool` callbacks
- putting MCP servers behind auth and least-privilege scopes
