# Project memory: RCA API behavior

When asked to perform RCA:
- Prefer tool-driven evidence gathering over guessing.
- Produce an RCA that is decision-grade: root cause, contributing factors, immediate fix, preventative fix.
- Include citations for factual claims. Citations must point to specific evidence items returned by tools.
- Keep log excerpts small and targeted; widen only if needed.
