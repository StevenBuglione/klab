import asyncio
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

from app.config import settings
from app.models import RcaRequest, RcaResponse, Citation
from app.agent_runner import run_rca

app = FastAPI(title="Claude Code RCA API (Starter)", version="0.1.0")

_sem = asyncio.Semaphore(settings.max_concurrent_rca)

@app.get("/health")
async def health():
    return {"ok": True}

@app.post("/v1/rca", response_model=RcaResponse)
async def rca(req: RcaRequest):
    async with _sem:
        try:
            result_msg, structured = await run_rca(
                pipeline_ref=req.pipeline_ref,
                question=req.question,
                session_id=req.session_id,
                max_turns=req.max_turns,
                verbose=req.verbose,
            )
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Agent execution failed: {e}") from e

    if result_msg is None:
        raise HTTPException(status_code=502, detail="No result returned from Claude Code runtime")

    # The Agent SDK returns a ResultMessage that includes:
    # - result (text)
    # - structured_output (for JSON schema)
    # - usage + cost metadata (when available)
    status = "ok" if not result_msg.is_error else "error"

    citations = []
    if isinstance(structured, dict):
        for c in structured.get("citations", []) or []:
            try:
                citations.append(Citation(**c))
            except Exception:
                # Keep going; bad citations shouldn't crash the endpoint
                pass

    return RcaResponse(
        status=status,
        session_id=getattr(result_msg, "session_id", None),
        rca=structured if isinstance(structured, dict) else None,
        citations=citations,
        raw_result=getattr(result_msg, "result", None),
        usage=getattr(result_msg, "usage", None),
        cost_usd=getattr(result_msg, "total_cost_usd", None),
        errors=[getattr(result_msg, "error", "")] if result_msg.is_error else [],
    )
