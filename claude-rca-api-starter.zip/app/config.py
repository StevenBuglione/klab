import os
from pydantic import BaseModel

class Settings(BaseModel):
    port: int = int(os.getenv("PORT", "8000"))
    max_concurrent_rca: int = int(os.getenv("MAX_CONCURRENT_RCA", "2"))

settings = Settings()
