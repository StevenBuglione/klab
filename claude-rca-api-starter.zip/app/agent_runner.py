import asyncio
import json
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Optional

from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient
from claude_agent_sdk.messages import ResultMessage

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MCP_FILE = PROJECT_ROOT / ".mcp.json"

# JSON schema for a stable API response payload.
# This is "prompt-enforced citations" (evidence IDs), not the native citations feature.
RCA_JSON_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "summary": {"type": "string"},
        "root_cause": {"type": "string"},
        "contributing_factors": {"type": "array", "items": {"type": "string"}},
        "recommended_fixes": {"type": "array", "items": {"type": "string"}},
        "citations": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "evidence_id": {"type": "string"},
                    "source": {"type": "string"},
                    "locator": {"type": "string"},
                    "quote": {"type": "string"},
                },
                "required": ["evidence_id", "source", "locator", "quote"],
            },
        },
    },
    "required": ["summary", "root_cause", "recommended_fixes", "citations"],
}

def _build_prompt(pipeline_ref: str, question: str) -> str:
    # The Skill should activate automatically based on description match.
    # We also explicitly mention it to make activation more deterministic.
    return f"""Use the **jenkins-rca** Skill.

Goal: perform a Root Cause Analysis (RCA) for a failed Jenkins pipeline using available MCP tools.

Pipeline reference:
{pipeline_ref}

User question:
{question}

Requirements:
- Use MCP tools to collect evidence (logs, stage info, commit diffs, Confluence runbooks, SourceBot KB matches).
- Prefer smaller targeted log excerpts over full logs; only widen if needed.
- Every factual claim must be backed by a citation pointing to an evidence item you collected.
- Output MUST conform to the JSON schema provided by the host.
"""

async def _message_stream(prompt: str) -> AsyncIterator[dict]:
    # Streaming mode prompt required when using MCP/custom tools.
    yield {
        "type": "user",
        "message": {
            "role": "user",
            "content": prompt
        }
    }

def build_options(max_turns: int, verbose: bool) -> ClaudeAgentOptions:
    # settings_sources=["project"] loads:
    # - Skills from .claude/skills/
    # - Memory from CLAUDE.md/.claude/CLAUDE.md
    # - Settings from .claude/settings.json
    # This is the recommended way to use Claude Code features in the Agent SDK.
    options = ClaudeAgentOptions(
        setting_sources=["project"],
        permission_mode="bypassPermissions",
        max_turns=max_turns,
        # Load MCP servers from the project file if present.
        # The SDK accepts a path for mcp_servers.
        mcp_servers=str(MCP_FILE) if MCP_FILE.exists() else {},
        # Use JSON Schema output so FastAPI can parse structured output reliably.
        output_format={"type": "json_schema", "schema": RCA_JSON_SCHEMA},
        # Ensure the agent runs in the repo (so Skills + .mcp.json are in scope)
        cwd=str(PROJECT_ROOT),
        # Tighten defaults by disallowing system-side-effect tools unless you explicitly need them.
        disallowed_tools=["Bash", "Write", "Edit"],
        # Optional: send verbose flag down to Claude Code CLI (debugging).
        extra_args={"verbose": "true"} if verbose else {},
    )
    return options

async def run_rca(pipeline_ref: str, question: str, session_id: Optional[str], max_turns: int, verbose: bool):
    prompt = _build_prompt(pipeline_ref, question)
    options = build_options(max_turns=max_turns, verbose=verbose)

    async with ClaudeSDKClient(options=options) as client:
        # Resume a prior session if provided; otherwise, start a new one.
        sid = session_id or "default"
        await client.query(_message_stream(prompt), session_id=sid)

        structured_output = None
        result_message: Optional[ResultMessage] = None

        async for msg in client.receive_response():
            if isinstance(msg, ResultMessage):
                result_message = msg
                structured_output = getattr(msg, "structured_output", None)

        return result_message, structured_output
