from pydantic import BaseModel, Field
from typing import Optional, Any, List, Dict

class RcaRequest(BaseModel):
    pipeline_ref: str = Field(..., description="Identifier for the Jenkins pipeline run (URL, job/build, etc.)")
    question: str = Field(..., description="What you want the RCA agent to answer")
    # Optional: if you want to resume a prior investigation session
    session_id: Optional[str] = Field(None, description="Claude Code session ID to resume")
    max_turns: int = Field(18, ge=1, le=50)
    verbose: bool = False

class Citation(BaseModel):
    evidence_id: str
    source: str
    locator: str
    quote: str

class RcaResponse(BaseModel):
    status: str
    session_id: Optional[str] = None
    rca: Optional[Dict[str, Any]] = None
    citations: List[Citation] = []
    raw_result: Optional[str] = None
    usage: Optional[Dict[str, Any]] = None
    cost_usd: Optional[float] = None
    errors: List[str] = []
